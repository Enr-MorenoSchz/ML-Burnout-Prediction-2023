# Grupo4-Practica2
Repositorio para la 2ª Práctica de la asignatura de Aprendizaje Automático [3º Curso]
